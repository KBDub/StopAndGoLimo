# Email Mailable System — Quote Notification

A complete Laravel Mailable implementation that fires an HTML email notification
whenever a visitor submits a quote request form. Includes the Mailable class, an
HTML email template, a controller with validation, reCAPTCHA, and a honeypot, and
the Eloquent model that backs the submission.

---

## What is included

```
app/
  Mail/
    QuoteSubmitted.php                  — the Mailable class
  Http/Controllers/
    QuoteController.php                 — form handler (validate, save, send)
  Models/
    CustomOrderRequest.php              — Eloquent model for submissions

resources/views/
  emails/
    quote-submitted.blade.php           — inline-CSS HTML email template
```

---

## Requirements

| Requirement | Notes |
|---|---|
| Laravel 10 / 11 / 12 | Uses `Mail::`, `Mailable`, `Envelope`, `Content` |
| A working SMTP or API mail driver | Mailgun, Postmark, SES, SMTP, or any driver supported by Laravel |
| PostgreSQL or MySQL | The model uses a standard Eloquent table with a JSON `payload` column |
| reCAPTCHA v2 Invisible (optional) | Only validated in `production` environment — safe to skip in dev |
| No extra composer packages | All dependencies ship with Laravel |

---

## Installation

### Step 1 — Copy the files

Drop all four files into your project following the directory structure above.

### Step 2 — Create the database migration

The model maps to a `custom_order_requests` table. Create the migration:

```bash
php artisan make:migration create_custom_order_requests_table
```

Paste this schema into the generated file:

```php
Schema::create('custom_order_requests', function (Blueprint $table) {
    $table->id();
    $table->string('reference', 30)->unique();
    $table->string('order_type', 50)->default('quote');
    $table->string('contact_name', 150);
    $table->string('contact_email', 255);
    $table->string('contact_phone', 50);
    $table->json('payload');
    $table->string('stripe_session_id')->nullable();
    $table->string('stripe_checkout_url')->nullable();
    $table->string('status', 30)->default('pending');
    $table->timestamp('submitted_at')->nullable();
    $table->timestamps();
});
```

Then run:

```bash
php artisan migrate
```

### Step 3 — Add the route

```php
use App\Http\Controllers\QuoteController;

Route::post('/get-a-quote', [QuoteController::class, 'submit'])->name('get-a-quote');
```

The controller redirects back to the named route `get-a-quote` on both success and
failure. If your form lives at a different URL or uses a different route name, update
the two `redirect()->route('get-a-quote')` calls in `QuoteController::submit()`.

### Step 4 — Configure mail environment variables

Add these to your `.env` file:

```env
MAIL_MAILER=smtp
MAIL_HOST=your-smtp-host
MAIL_PORT=587
MAIL_USERNAME=your-username
MAIL_PASSWORD=your-password
MAIL_ENCRYPTION=tls
MAIL_FROM_ADDRESS=noreply@yourdomain.com
MAIL_FROM_NAME="Your App Name"
```

See `config/mail.php` for all supported drivers (Mailgun, Postmark, SES, etc.).

### Step 5 — Set the notification recipients

The recipients are currently hardcoded in `QuoteController::submit()`:

```php
$recipients = [
    'vincent@newlenoxlimoservice.com',
    'stopngovr@gmail.com',
];
```

For a new project, either replace these addresses directly, or move them to `.env`
for easier management:

```env
QUOTE_NOTIFY_EMAIL=owner@yourdomain.com
QUOTE_NOTIFY_EMAIL_2=backup@yourdomain.com
```

Then in the controller:

```php
$recipients = array_filter([
    env('QUOTE_NOTIFY_EMAIL'),
    env('QUOTE_NOTIFY_EMAIL_2'),
]);
```

The BCC address (`support@apexwebseo.com`) on line 124 of the controller is
project-specific. Remove or replace it:

```php
// Remove BCC entirely
Mail::to($recipients)->send(new QuoteSubmitted($quote));

// Or set your own BCC
Mail::to($recipients)->bcc('admin@yourdomain.com')->send(new QuoteSubmitted($quote));
```

### Step 6 — Configure reCAPTCHA (optional)

reCAPTCHA verification only runs when `APP_ENV=production` and the secret key is
present. To use it:

1. Register your domain at https://www.google.com/recaptcha/admin
2. Choose reCAPTCHA v2 Invisible
3. Add to `.env`:

```env
RECAPTCHA_SECRET_KEY=your-secret-key
RECAPTCHA_SITE_KEY=your-site-key
```

4. Add to `config/services.php`:

```php
'recaptcha' => [
    'secret_key' => env('RECAPTCHA_SECRET_KEY'),
    'site_key'   => env('RECAPTCHA_SITE_KEY'),
],
```

5. In your form Blade file, load the reCAPTCHA widget and pass `g_recaptcha_response`
   as a hidden input on submit. The controller expects this field name.

To disable reCAPTCHA entirely, remove the reCAPTCHA block (lines 22-48 of
`QuoteController.php`) and the `Http` facade import.

---

## How the submission flow works

```
User submits form
    |
    v
QuoteController::submit()
    |-- [Production only] reCAPTCHA v2 verify via Google API
    |       Fail -> redirect back with error
    |
    |-- Honeypot check (field: sg_website)
    |       Filled -> fake success (bot discarded silently)
    |
    |-- Validate 9 fields (name, phone, email, vehicle_type,
    |   passengers, pickup_location, destination, booking_date,
    |   additional_info)
    |       Fail -> redirect back with validation errors
    |
    |-- Save CustomOrderRequest to database
    |       Fail -> redirect back with error
    |
    |-- Mail::to($recipients)->bcc(...)->send(new QuoteSubmitted($quote))
    |       Fail -> logged, user still sees success (graceful degradation)
    |
    v
Redirect to /get-a-quote with session flash:
    quote_success  = true
    quote_name     = first name only
    quote_reference = SG-QT-XXXXXXXX
```

---

## The Mailable class

`QuoteSubmitted` accepts a `CustomOrderRequest` model instance and exposes it to the
view as `$quote`. It uses the Laravel 9+ `Envelope` / `Content` API:

```php
public function envelope(): Envelope
{
    return new Envelope(
        subject: 'New Quote Request - ' . $this->quote->reference,
    );
}

public function content(): Content
{
    return new Content(view: 'emails.quote-submitted');
}
```

The subject uses a hyphen in the export. The original used an em dash, which has
been corrected here.

---

## The email template

`quote-submitted.blade.php` is a self-contained HTML email with inline CSS — no
Tailwind, no external stylesheet, no images. It is safe to send to all major email
clients (Gmail, Outlook, Apple Mail).

Sections rendered in the email:

- Header with company name
- Reference number badge
- Contact Information table (name, phone, email)
- Trip Details table (vehicle type, passengers, pickup, destination, booking date)
- Additional Information block (only rendered when present)
- Reply CTA button (mailto link directly to the customer)
- Footer with company details

To rebrand the template for a new project:

1. Replace the header company name (line 31)
2. Replace the footer company name and phone (line 98)
3. Swap `#0b1f3a` (navy) and `#c9a84c` (gold) for your brand colors
4. Update field labels in the Trip Details table to match your form fields

---

## Adapting the model for a different form

`CustomOrderRequest::payload` is a JSON column that stores the full validated array.
The email template reads fields from `$quote->payload['field_name']`. To adapt this
for a different form:

1. Update the `$validated` array in `QuoteController::submit()` with your fields
2. Update the Trip Details table in `quote-submitted.blade.php` to reference your
   field keys via `$quote->payload['your_field']`
3. Add or remove rows from the validation rules to match

If you prefer a flat model (individual columns instead of a JSON payload), replace
`$quote->payload['field_name']` references in the view with direct model property
access (`$quote->field_name`) and update the migration accordingly.

---

## Queuing (optional)

Mail is currently sent synchronously. For high-traffic sites, switch to queued mail:

```php
// In QuoteController, replace:
Mail::to($recipients)->bcc('...')->send(new QuoteSubmitted($quote));

// With:
Mail::to($recipients)->bcc('...')->queue(new QuoteSubmitted($quote));
```

Then run a queue worker:

```bash
php artisan queue:work
```

Ensure your `QUEUE_CONNECTION` is set to something other than `sync` in `.env`
(e.g., `database`, `redis`, `sqs`).

---

## Honeypot field

The controller checks for a field named `sg_website`. If it is filled (bots often
fill every field), the submission is silently discarded and a fake success is shown.
Rename the honeypot field to anything less guessable for your project:

In `QuoteController::submit()`:
```php
// Line 51 — rename sg_website to your field name
if ($request->filled('your_honeypot_field_name')) {
```

In your form Blade file, add a hidden input with the matching name and CSS that
hides it from real users:

```html
<input type="text" name="your_honeypot_field_name" value=""
       style="position:absolute;left:-9999px;opacity:0;" tabindex="-1" autocomplete="off">
```

---

## Required .env variables

| Variable | Required | Purpose |
|---|---|---|
| `MAIL_MAILER` | Yes | Driver: smtp, mailgun, postmark, ses, log |
| `MAIL_HOST` | Yes (SMTP) | SMTP server hostname |
| `MAIL_PORT` | Yes (SMTP) | 587 for TLS, 465 for SSL |
| `MAIL_USERNAME` | Yes (SMTP) | SMTP username |
| `MAIL_PASSWORD` | Yes (SMTP) | SMTP password |
| `MAIL_ENCRYPTION` | Yes (SMTP) | tls or ssl |
| `MAIL_FROM_ADDRESS` | Yes | Sender address |
| `MAIL_FROM_NAME` | Yes | Sender display name |
| `RECAPTCHA_SECRET_KEY` | No | Only needed if using reCAPTCHA in production |
| `RECAPTCHA_SITE_KEY` | No | Only needed in your frontend Blade form |
| `APP_ENV` | Yes | Set to `production` to activate reCAPTCHA enforcement |

---

## Portability checklist

Before going live in a new project, run through this list:

- [ ] Migration created and run (`php artisan migrate`)
- [ ] Route added to `web.php` or equivalent
- [ ] Route name in both `redirect()->route('...')` calls updated if different
- [ ] MAIL_* variables configured in `.env`
- [ ] Recipient addresses updated (or moved to `.env`)
- [ ] BCC address removed or replaced
- [ ] Honeypot field name updated in controller and form template
- [ ] reCAPTCHA configured (or block removed if not using it)
- [ ] Email template rebranded (company name, colors)
- [ ] Trip Details table fields updated to match your form
- [ ] `config/services.php` recaptcha block added (if using reCAPTCHA)
