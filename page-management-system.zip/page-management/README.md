# Page Management System

A developer dashboard for Laravel TALL-stack projects. It scans all Blade page files,
extracts every component used, groups them by page and by top-level URL section, and
renders a searchable, filterable, bi-directional registry — all with zero database
dependency and no third-party composer packages.

---

## What is included

```
app/
  Actions/
    ScanPageComponents.php              — scanner engine (pure PHP, no deps)

resources/views/
  pages/
    page-management.blade.php           — main dashboard shell
  components/ui/
    page-management-page-card.blade.php     — per-page expandable card
    page-management-registry-card.blade.php — per-component registry card
    page-management-legend.blade.php        — color legend
```

---

## Requirements

| Requirement | Notes |
|---|---|
| Laravel 10 / 11 / 12 | Uses `File::`, `Str::`, `resource_path()` — all stock Laravel |
| Tailwind CSS | Dashboard views are styled entirely with Tailwind utility classes |
| Alpine.js | Accordion open/close, component expand, inter-link events. Livewire v3 bundles Alpine automatically. If you are not using Livewire, import Alpine separately. |
| No extra composer packages | `illuminate/filesystem` and `illuminate/support` are bundled with every Laravel install |

---

## Installation

### Step 1 — Copy the files

Drop the files into your project following the directory structure above. The paths
are standard Laravel conventions and should require no adjustment.

### Step 2 — Add the route

Open `routes/web.php` (or a sub-route file you include from it) and add one line:

```php
use App\Actions\ScanPageComponents;

Route::get('/page-management', function () {
    $groups = (new ScanPageComponents())->execute();
    return view('pages.page-management', compact('groups'));
})->name('page-management');
```

Protect this route so it is never publicly reachable in production (see Step 3).

### Step 3 — Restrict access

The dashboard exposes your full component architecture. Gate it behind middleware
before deploying:

```php
// Option A — environment check (simplest)
Route::get('/page-management', function () { ... })->middleware('web');

// In AppServiceProvider::boot() or a dedicated middleware:
abort_unless(app()->isLocal(), 403);

// Option B — Laravel auth + a gate/role check
Route::get('/page-management', function () { ... })->middleware(['auth', 'role:developer']);

// Option C — IP allowlist (useful for staging)
Route::get('/page-management', function () { ... })->middleware('allow.ips:127.0.0.1,10.0.0.0/8');
```

### Step 4 — Adapt the scan path (if needed)

`ScanPageComponents::execute()` scans `resource_path('views/pages')`. If your project
keeps page Blade files elsewhere, change the one line in `execute()`:

```php
// Default
$pagesPath = resource_path('views/pages');

// Example — if your pages live in resources/views/livewire/pages
$pagesPath = resource_path('views/livewire/pages');
```

### Step 5 — Adapt the master layout wrapper

`page-management.blade.php` opens with `<x-layouts.page ...>` — a project-specific
master layout component. Replace this with whatever your project uses:

```blade
{{-- Replace this header line --}}
<x-layouts.page title="Page Management" :noIndex="true">

{{-- With your own layout, for example: --}}
@extends('layouts.app')
@section('content')
```

Close the file with the matching closing tag or `@endsection`.

---

## How the scanner works

`ScanPageComponents::execute()` runs four steps:

1. **File walk** — uses `File::allFiles()` to find every `.blade.php` file under the
   pages directory. Skips files whose URL maps to `/demo`.

2. **Component extraction** — two regex passes per file:
   - `<x-*>` tags: captures the component name and its full attribute string.
   - `@livewire('...')` directives: captures the component name.
   All matches are sorted by byte-offset so the order in the dashboard reflects the
   order they appear in the file.

3. **Prop diffing** — for each `<x-*>` component, the scanner opens the component
   Blade file, parses its `@props([...])` block, and compares the defaults against
   what was passed at the call site. Overrides are stored as
   `['value' => '...', 'default' => '...']` pairs and rendered as amber chips.

4. **Grouping** — pages are grouped by the first segment of their URL
   (`/about/team` → group "About"). Shared components (used on two or more pages)
   are counted and surfaced in a dedicated accordion.

---

## Component naming convention

The scanner classifies components by their `x-` prefix:

| Prefix | Category |
|---|---|
| `x-sections.*` | Full-width page sections |
| `x-ui.*` | Reusable UI widgets |
| `x-layout.*` | Structural layout wrappers |
| `livewire:*` | Livewire components |
| anything else | "Other" |

If your project uses different prefixes, update the `if/elseif` chains in
`ScanPageComponents::extractComponents()` and the matching chains in the three
view files.

---

## Dynamic template detection

Pages that consume route-injected variables (`$slug`, `$parent`, `$child`,
`$orderId`, etc.) are flagged with a "Dynamic" badge. Add any custom variable names
to the regex in `ScanPageComponents::detectDynamicTemplate()`:

```php
return (bool) preg_match(
    '/\$(?:slug|parent|child|orderId|yourCustomVar)\b/',
    $content
);
```

---

## Inter-link events

The dashboard uses two custom Alpine/window events for bi-directional navigation:

| Event | Direction | Effect |
|---|---|---|
| `pm-open-registry` | Page card to registry | Opens the All Components accordion, scrolls to the target card, flashes a ring highlight |
| `pm-open-page` | Registry card to page card | Opens the Pages accordion, scrolls to the target page card, flashes a ring highlight |

These are dispatched via `window.dispatchEvent(new CustomEvent(...))` — no Alpine
plugin or extra library needed.

---

## Color system

The dashboard uses 16 Tailwind color families (blue, amber, emerald, purple, rose,
cyan, orange, indigo, pink, teal, lime, fuchsia, sky, violet, red, yellow) and
assigns one to each unique component by index. Colors are assigned in sort order so
the same component always gets the same color within a session.

Because the color classes are dynamically constructed, Tailwind's JIT scanner will
not detect them. Add a safelist to `tailwind.config.js`:

```js
safelist: [
  { pattern: /^(bg|text|border)-(blue|amber|emerald|purple|rose|cyan|orange|indigo|pink|teal|lime|fuchsia|sky|violet|red|yellow)-(50|200|400|700)$/ },
  { pattern: /^bg-(blue|amber|emerald|purple|rose|cyan|orange|indigo|pink|teal|lime|fuchsia|sky|violet|red|yellow)-400$/ },
]
```

Alternatively, the dashboard already includes a hidden `<div>` with representative
classes to help JIT detect them:

```blade
{{-- Tailwind safelist for dynamic inter-link classes --}}
<div class="hidden ring-2 ring-champagne bg-champagne/10 transition-all duration-300"></div>
```

You can extend this div with any additional classes your color palette requires.

---

## CSS custom properties

The dashboard uses CSS custom properties for its dark-navy color scheme:

```css
--navy           dark navy background
--navy-light     slightly lighter navy (accordion backgrounds)
--navy-dark      darker navy (card backgrounds)
--cloud-light    near-white text
--champagne      gold accent
--azure          blue accent (informational)
--slate          muted grey text
--white          pure white
```

Define these in your project's `app.css` or replace them with Tailwind classes or
your own design tokens. If your project does not use CSS custom properties, do a
find-and-replace of every `var(--*)` reference in the three view files.

---

## What is NOT included

- No migration. No database table. The scanner reads files only.
- No authentication. You must add your own route guard (see Step 3).
- No JavaScript build step. Everything is vanilla Alpine.js + inline JS.
- No seeder or factory.

---

## Portability checklist

Before going live in a new project, run through this list:

- [ ] Route added to `web.php` or equivalent
- [ ] Route is protected by appropriate middleware
- [ ] `$pagesPath` in `execute()` matches your pages directory
- [ ] Master layout wrapper in `page-management.blade.php` replaced with your layout
- [ ] CSS custom properties defined or replaced
- [ ] Tailwind safelist added (or the hidden div extended)
- [ ] Component prefix conventions (`sections.`, `ui.`, `layout.`) match your project
- [ ] Dynamic variable names in `detectDynamicTemplate()` updated if needed
